/**
 * ================================================================
 *  GOOGLE APPS SCRIPT - ANNOUNCEMENT SHEET
 *  AN Clinic - Announcement Management System
 * ================================================================
 * 
 * SHEET STRUCTURE (Create a Google Sheet with these columns):
 * | Timestamp | Title | Message | ImageURL | Priority | Active | ExpiryDate | Author |
 * 
 * PRIORITY LEVELS: high, normal, low
 * ACTIVE: yes/no
 * EXPIRYDATE: Date when announcement should stop showing (optional, format: YYYY-MM-DD)
 * 
 * DEPLOYMENT INSTRUCTIONS:
 * 1. Create a new Google Sheet
 * 2. Add headers in Row 1 as shown above
 * 3. Go to Extensions > Apps Script
 * 4. Delete default code and paste this entire script
 * 5. Save the project (Ctrl+S)
 * 6. Click Deploy > New Deployment
 * 7. Select Type: Web App
 * 8. Execute as: Me
 * 9. Who has access: Anyone
 * 10. Click Deploy and copy the Web App URL
 * 11. Use this URL in your website's BACKEND_URL for announcement actions
 */

// Sheet name for announcements
const ANNOUNCEMENT_SHEET_NAME = 'Announcements';

/**
 * Main entry point for web requests
 */
function doGet(e) {
  const action = e.parameter.action;
  
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    switch(action) {
      case 'getAnnouncements':
        return getAnnouncements(headers);
      case 'getActive':
        return getActiveAnnouncements(headers);
      default:
        return jsonResponse({ error: 'Invalid action' }, headers, 400);
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle POST requests (add/update announcement)
 */
function doPost(e) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    const data = JSON.parse(e.postData.contents);
    
    switch(data.action) {
      case 'addAnnouncement':
        return addAnnouncement(data, headers);
      case 'updateAnnouncement':
        return updateAnnouncement(data, headers);
      case 'deleteAnnouncement':
        return deleteAnnouncement(data, headers);
      default:
        return jsonResponse({ error: 'Invalid action' }, headers, 400);
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle OPTIONS for CORS preflight
 */
function doOptions(e) {
  return ContentService.createTextOutput()
    .setHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
}

/**
 * Get all announcements (for admin)
 */
function getAnnouncements(headers) {
  const sheet = getSheet(ANNOUNCEMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ announcements: [] }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const announcements = [];
  
  // Start from row 2 (skip header)
  for (let i = 1; i < data.length; i++) {
    announcements.push({
      rowId: i + 1,
      timestamp: formatDate(data[i][0]),
      title: data[i][1] || '',
      message: data[i][2] || '',
      imageUrl: data[i][3] || '',
      priority: data[i][4] || 'normal',
      active: data[i][5] || 'no',
      expiryDate: formatDate(data[i][6]),
      author: data[i][7] || ''
    });
  }
  
  // Sort by timestamp (newest first)
  announcements.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  return jsonResponse({ announcements: announcements }, headers);
}

/**
 * Get only active and non-expired announcements (for website)
 */
function getActiveAnnouncements(headers) {
  const sheet = getSheet(ANNOUNCEMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ announcements: [] }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const announcements = [];
  const now = new Date();
  
  // Start from row 2 (skip header)
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    
    // Check if active
    if (row[5] !== 'yes') continue;
    
    // Check expiry date
    if (row[6]) {
      const expiry = new Date(row[6]);
      if (expiry < now) continue;
    }
    
    announcements.push({
      timestamp: formatDate(row[0]),
      title: row[1] || '',
      message: row[2] || '',
      imageUrl: row[3] || '',
      priority: row[4] || 'normal',
      active: row[5] || 'no',
      expiryDate: formatDate(row[6]),
      author: row[7] || ''
    });
  }
  
  // Sort by priority (high first) then by timestamp
  const priorityOrder = { high: 0, normal: 1, low: 2 };
  announcements.sort((a, b) => {
    const pDiff = (priorityOrder[a.priority] || 1) - (priorityOrder[b.priority] || 1);
    if (pDiff !== 0) return pDiff;
    return new Date(b.timestamp) - new Date(a.timestamp);
  });
  
  return jsonResponse({ announcements: announcements }, headers);
}

/**
 * Add new announcement
 */
function addAnnouncement(data, headers) {
  const sheet = getOrCreateSheet(ANNOUNCEMENT_SHEET_NAME, 
    ['Timestamp', 'Title', 'Message', 'ImageURL', 'Priority', 'Active', 'ExpiryDate', 'Author']);
  
  const timestamp = new Date();
  const row = [
    timestamp,
    data.title || '',
    data.message || '',
    data.imageUrl || '',
    data.priority || 'normal',
    data.active || 'yes',
    data.expiryDate || '',
    data.author || 'Admin'
  ];
  
  sheet.appendRow(row);
  
  return jsonResponse({ 
    success: true, 
    message: 'Announcement added successfully!'
  }, headers);
}

/**
 * Update existing announcement
 */
function updateAnnouncement(data, headers) {
  const sheet = getSheet(ANNOUNCEMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ error: 'Sheet not found' }, headers, 404);
  }
  
  const rowNumber = data.rowId;
  if (!rowNumber || rowNumber < 2) {
    return jsonResponse({ error: 'Invalid row ID' }, headers, 400);
  }
  
  // Update fields
  if (data.title !== undefined) sheet.getRange(rowNumber, 2).setValue(data.title);
  if (data.message !== undefined) sheet.getRange(rowNumber, 3).setValue(data.message);
  if (data.imageUrl !== undefined) sheet.getRange(rowNumber, 4).setValue(data.imageUrl);
  if (data.priority !== undefined) sheet.getRange(rowNumber, 5).setValue(data.priority);
  if (data.active !== undefined) sheet.getRange(rowNumber, 6).setValue(data.active);
  if (data.expiryDate !== undefined) sheet.getRange(rowNumber, 7).setValue(data.expiryDate);
  
  return jsonResponse({ 
    success: true, 
    message: 'Announcement updated successfully!'
  }, headers);
}

/**
 * Delete announcement
 */
function deleteAnnouncement(data, headers) {
  const sheet = getSheet(ANNOUNCEMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ error: 'Sheet not found' }, headers, 404);
  }
  
  const rowNumber = data.rowId;
  if (!rowNumber || rowNumber < 2) {
    return jsonResponse({ error: 'Invalid row ID' }, headers, 400);
  }
  
  sheet.deleteRow(rowNumber);
  
  return jsonResponse({ 
    success: true, 
    message: 'Announcement deleted successfully!'
  }, headers);
}

/**
 * Helper: Get sheet by name
 */
function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(name);
}

/**
 * Helper: Get or create sheet
 */
function getOrCreateSheet(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (headers) {
      sheet.appendRow(headers);
      // Format header row
      sheet.getRange(1, 1, 1, headers.length)
        .setFontWeight('bold')
        .setBackground('#c9a84c')
        .setFontColor('white');
    }
  }
  
  return sheet;
}

/**
 * Helper: Format date
 */
function formatDate(date) {
  if (!date) return '';
  const d = new Date(date);
  return Utilities.formatDate(d, 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss');
}

/**
 * Helper: JSON response
 */
function jsonResponse(data, headers, statusCode) {
  const output = ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  
  // Set headers
  for (const [key, value] of Object.entries(headers)) {
    output.setHeader(key, value);
  }
  
  return output;
}

/**
 * ADMIN FUNCTIONS (Run these from Apps Script editor)
 */

/**
 * Quick add announcement from script
 */
function quickAddAnnouncement(title, message, priority, expiryDays) {
  const sheet = getOrCreateSheet(ANNOUNCEMENT_SHEET_NAME, 
    ['Timestamp', 'Title', 'Message', 'ImageURL', 'Priority', 'Active', 'ExpiryDate', 'Author']);
  
  const expiryDate = expiryDays ? new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000) : '';
  
  const row = [
    new Date(),
    title,
    message,
    '', // imageUrl
    priority || 'normal',
    'yes',
    expiryDate,
    'Admin'
  ];
  
  sheet.appendRow(row);
  console.log('Announcement added: ' + title);
}

/**
 * Deactivate expired announcements
 */
function deactivateExpired() {
  const sheet = getSheet(ANNOUNCEMENT_SHEET_NAME);
  if (!sheet) return;
  
  const data = sheet.getDataRange().getValues();
  const now = new Date();
  let deactivated = 0;
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][6]) { // Has expiry date
      const expiry = new Date(data[i][6]);
      if (expiry < now && data[i][5] === 'yes') {
        sheet.getRange(i + 1, 6).setValue('no');
        deactivated++;
      }
    }
  }
  
  console.log('Deactivated ' + deactivated + ' expired announcements');
}

/**
 * Get announcement statistics
 */
function getStats() {
  const sheet = getSheet(ANNOUNCEMENT_SHEET_NAME);
  if (!sheet) {
    console.log('No announcements sheet found');
    return;
  }
  
  const data = sheet.getDataRange().getValues();
  let total = 0;
  let active = 0;
  let highPriority = 0;
  
  for (let i = 1; i < data.length; i++) {
    total++;
    if (data[i][5] === 'yes') active++;
    if (data[i][4] === 'high') highPriority++;
  }
  
  console.log('Total: ' + total);
  console.log('Active: ' + active);
  console.log('High Priority: ' + highPriority);
}
