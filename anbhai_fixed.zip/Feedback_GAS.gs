/**
 * ================================================================
 *  GOOGLE APPS SCRIPT - FEEDBACK SHEET
 *  AN Clinic - Patient Feedback Management System
 * ================================================================
 * 
 * SHEET STRUCTURE (Create a Google Sheet with these columns):
 * | Timestamp | Patient Name | Rating (1-5) | Feedback Text | Phone | Email | Status | Reply |
 * 
 * DEPLOYMENT INSTRUCTIONS:
 * 1. Create a new Google Sheet
 * 2. Add headers in Row 1 as shown above
 * 3. Go to Extensions > Apps Script
 * 4. Delete default code and paste this entire script
 * 5. Save the project (Ctrl+S)
 * 6. Click Deploy > New Deployment
 * 7. Select Type: Web App
 * 8. Execute as: Me
 * 9. Who has access: Anyone
 * 10. Click Deploy and copy the Web App URL
 * 11. Use this URL in your website's BACKEND_URL for feedback actions
 */

// Sheet name for feedback
const FEEDBACK_SHEET_NAME = 'Feedback';

/**
 * Main entry point for web requests
 */
function doGet(e) {
  const action = e.parameter.action;
  
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    switch(action) {
      case 'getFeedback':
        return getFeedback(headers);
      case 'getStats':
        return getFeedbackStats(headers);
      default:
        return jsonResponse({ error: 'Invalid action' }, headers, 400);
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle POST requests (submit feedback)
 */
function doPost(e) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    const data = JSON.parse(e.postData.contents);
    
    if (data.action === 'submitFeedback') {
      return submitFeedback(data, headers);
    }
    
    return jsonResponse({ error: 'Invalid action' }, headers, 400);
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle OPTIONS for CORS preflight
 */
function doOptions(e) {
  return ContentService.createTextOutput()
    .setHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
}

/**
 * Get all feedback entries (approved ones only)
 */
function getFeedback(headers) {
  const sheet = getSheet(FEEDBACK_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ feedback: [] }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const feedback = [];
  
  // Start from row 2 (skip header)
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    
    // Only show approved feedback (Status column = 'Approved' or empty)
    if (row[6] !== 'Rejected') {
      feedback.push({
        timestamp: formatDate(row[0]),
        name: row[1] || 'Anonymous',
        stars: parseInt(row[2]) || 5,
        text: row[3] || '',
        phone: row[4] || '',
        email: row[5] || '',
        status: row[6] || 'Pending',
        reply: row[7] || ''
      });
    }
  }
  
  // Sort by timestamp (newest first)
  feedback.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  return jsonResponse({ feedback: feedback }, headers);
}

/**
 * Submit new feedback
 */
function submitFeedback(data, headers) {
  const sheet = getOrCreateSheet(FEEDBACK_SHEET_NAME, 
    ['Timestamp', 'Patient Name', 'Rating', 'Feedback Text', 'Phone', 'Email', 'Status', 'Reply']);
  
  const timestamp = new Date();
  const row = [
    timestamp,
    data.name || 'Anonymous',
    data.rating || 5,
    data.text || '',
    data.phone || '',
    data.email || '',
    'Pending', // Default status
    '' // Reply
  ];
  
  sheet.appendRow(row);
  
  // Send email notification to admin (optional)
  sendNotification('New Feedback Received', 
    `Patient: ${data.name}\nRating: ${data.rating}/5\nFeedback: ${data.text}`);
  
  return jsonResponse({ 
    success: true, 
    message: 'Thank you for your feedback!' 
  }, headers);
}

/**
 * Get feedback statistics
 */
function getFeedbackStats(headers) {
  const sheet = getSheet(FEEDBACK_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ 
      total: 0, 
      average: 0, 
      fiveStar: 0 
    }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  let total = 0;
  let sum = 0;
  let fiveStar = 0;
  
  for (let i = 1; i < data.length; i++) {
    const rating = parseInt(data[i][2]);
    if (rating) {
      total++;
      sum += rating;
      if (rating === 5) fiveStar++;
    }
  }
  
  const average = total > 0 ? (sum / total).toFixed(1) : 0;
  
  return jsonResponse({
    total: total,
    average: average,
    fiveStar: fiveStar
  }, headers);
}

/**
 * Helper: Get sheet by name
 */
function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(name);
}

/**
 * Helper: Get or create sheet
 */
function getOrCreateSheet(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (headers) {
      sheet.appendRow(headers);
      // Format header row
      sheet.getRange(1, 1, 1, headers.length)
        .setFontWeight('bold')
        .setBackground('#4285f4')
        .setFontColor('white');
    }
  }
  
  return sheet;
}

/**
 * Helper: Format date
 */
function formatDate(date) {
  if (!date) return '';
  const d = new Date(date);
  return Utilities.formatDate(d, 'Asia/Kolkata', 'dd MMM yyyy');
}

/**
 * Helper: JSON response
 */
function jsonResponse(data, headers, statusCode) {
  const output = ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  
  // Set headers
  for (const [key, value] of Object.entries(headers)) {
    output.setHeader(key, value);
  }
  
  return output;
}

/**
 * Helper: Send email notification
 */
function sendNotification(subject, body) {
  try {
    // Replace with your email
    const adminEmail = 'your-email@example.com';
    MailApp.sendEmail(adminEmail, subject, body);
  } catch(e) {
    console.log('Email notification failed:', e);
  }
}

/**
 * ADMIN FUNCTIONS (Run these from Apps Script editor)
 */

/**
 * Approve a feedback entry
 * Run this and pass the row number
 */
function approveFeedback(rowNumber) {
  const sheet = getSheet(FEEDBACK_SHEET_NAME);
  if (sheet) {
    sheet.getRange(rowNumber, 7).setValue('Approved');
    console.log('Feedback approved at row ' + rowNumber);
  }
}

/**
 * Reply to a feedback entry
 */
function replyToFeedback(rowNumber, replyText) {
  const sheet = getSheet(FEEDBACK_SHEET_NAME);
  if (sheet) {
    sheet.getRange(rowNumber, 8).setValue(replyText);
    console.log('Reply added to row ' + rowNumber);
  }
}

/**
 * Get all pending feedback for review
 */
function getPendingFeedback() {
  const sheet = getSheet(FEEDBACK_SHEET_NAME);
  if (!sheet) return [];
  
  const data = sheet.getDataRange().getValues();
  const pending = [];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][6] === 'Pending') {
      pending.push({
        row: i + 1,
        timestamp: data[i][0],
        name: data[i][1],
        rating: data[i][2],
        text: data[i][3]
      });
    }
  }
  
  console.log('Pending feedback:', pending);
  return pending;
}
