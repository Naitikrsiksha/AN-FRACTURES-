/**
 * ================================================================
 *  GOOGLE APPS SCRIPT - APPOINTMENT SHEET
 *  AN Clinic - Appointment Management System
 * ================================================================
 * 
 * SHEET STRUCTURE (Create a Google Sheet with these columns):
 * | Timestamp | Name | Mobile | Age | Date | Time | Problem | Doctor | Status | Notes | UTR |
 * 
 * STATUS OPTIONS: Pending, Confirmed, Completed, Cancelled, No-Show
 * 
 * DEPLOYMENT INSTRUCTIONS:
 * 1. Create a new Google Sheet
 * 2. Add headers in Row 1 as shown above
 * 3. Go to Extensions > Apps Script
 * 4. Delete default code and paste this entire script
 * 5. Save the project (Ctrl+S)
 * 6. Click Deploy > New Deployment
 * 7. Select Type: Web App
 * 8. Execute as: Me
 * 9. Who has access: Anyone
 * 10. Click Deploy and copy the Web App URL
 * 11. Use this URL in your website's BACKEND_URL for appointment actions
 */

// Sheet name for appointments
const APPOINTMENT_SHEET_NAME = 'Appointments';

/**
 * Main entry point for web requests
 */
function doGet(e) {
  const action = e.parameter.action;
  
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    switch(action) {
      case 'getAppointments':
        return getAppointments(headers);
      case 'getTodayAppointments':
        return getTodayAppointments(headers);
      case 'getStats':
        return getAppointmentStats(headers);
      default:
        return jsonResponse({ error: 'Invalid action' }, headers, 400);
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle POST requests
 */
function doPost(e) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    const data = JSON.parse(e.postData.contents);
    
    switch(data.action) {
      case 'appointment':
      case 'bookAppointment':
        return bookAppointment(data, headers);
      case 'updateAppointment':
        return updateAppointment(data, headers);
      case 'cancelAppointment':
        return cancelAppointment(data, headers);
      default:
        return jsonResponse({ error: 'Invalid action' }, headers, 400);
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle OPTIONS for CORS preflight
 */
function doOptions(e) {
  return ContentService.createTextOutput()
    .setHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
}

/**
 * Book new appointment
 */
function bookAppointment(data, headers) {
  const sheet = getOrCreateSheet(APPOINTMENT_SHEET_NAME, 
    ['Timestamp', 'Name', 'Mobile', 'Age', 'Date', 'Time', 'Problem', 'Doctor', 'Status', 'Notes', 'UTR']);
  
  // Check for duplicate appointments (same mobile, same date)
  const existing = findExistingAppointment(sheet, data.mobile, data.date);
  if (existing) {
    return jsonResponse({ 
      success: false, 
      message: 'Appointment already exists for this date. Please call to modify.'
    }, headers, 409);
  }
  
  const timestamp = new Date();
  const row = [
    timestamp,
    data.name || '',
    data.mobile || '',
    data.age || '',
    data.date || '',
    data.time || '',
    data.problem || '',
    data.doctor || 'Any Available',
    'Pending', // Default status
    '', // Notes
    data.utr || ''
  ];
  
  sheet.appendRow(row);
  
  // Send confirmation SMS/Email (optional)
  sendConfirmation(data);
  
  return jsonResponse({ 
    success: true, 
    message: 'Appointment booked successfully! We will confirm within 2 hours.',
    appointmentId: timestamp.getTime()
  }, headers);
}

/**
 * Get all appointments
 */
function getAppointments(headers) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ appointments: [] }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const appointments = [];
  
  // Start from row 2 (skip header)
  for (let i = 1; i < data.length; i++) {
    appointments.push({
      rowId: i + 1,
      timestamp: formatDate(data[i][0]),
      name: data[i][1] || '',
      mobile: data[i][2] || '',
      age: data[i][3] || '',
      date: formatDate(data[i][4]),
      time: data[i][5] || '',
      problem: data[i][6] || '',
      doctor: data[i][7] || '',
      status: data[i][8] || 'Pending',
      notes: data[i][9] || '',
      utr: data[i][10] || ''
    });
  }
  
  // Sort by date (newest first)
  appointments.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  return jsonResponse({ appointments: appointments }, headers);
}

/**
 * Get today's appointments
 */
function getTodayAppointments(headers) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ appointments: [], count: 0 }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const today = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  const appointments = [];
  
  for (let i = 1; i < data.length; i++) {
    const apptDate = data[i][4] ? Utilities.formatDate(new Date(data[i][4]), 'Asia/Kolkata', 'yyyy-MM-dd') : '';
    
    if (apptDate === today && data[i][8] !== 'Cancelled') {
      appointments.push({
        rowId: i + 1,
        timestamp: formatDate(data[i][0]),
        name: data[i][1] || '',
        mobile: data[i][2] || '',
        age: data[i][3] || '',
        date: formatDate(data[i][4]),
        time: data[i][5] || '',
        problem: data[i][6] || '',
        doctor: data[i][7] || '',
        status: data[i][8] || 'Pending',
        notes: data[i][9] || ''
      });
    }
  }
  
  return jsonResponse({ 
    appointments: appointments, 
    count: appointments.length 
  }, headers);
}

/**
 * Update appointment status
 */
function updateAppointment(data, headers) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ error: 'Sheet not found' }, headers, 404);
  }
  
  const rowNumber = data.rowId;
  if (!rowNumber || rowNumber < 2) {
    return jsonResponse({ error: 'Invalid row ID' }, headers, 400);
  }
  
  // Update fields
  if (data.status !== undefined) sheet.getRange(rowNumber, 9).setValue(data.status);
  if (data.doctor !== undefined) sheet.getRange(rowNumber, 8).setValue(data.doctor);
  if (data.notes !== undefined) sheet.getRange(rowNumber, 10).setValue(data.notes);
  if (data.time !== undefined) sheet.getRange(rowNumber, 6).setValue(data.time);
  
  return jsonResponse({ 
    success: true, 
    message: 'Appointment updated successfully!'
  }, headers);
}

/**
 * Cancel appointment
 */
function cancelAppointment(data, headers) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ error: 'Sheet not found' }, headers, 404);
  }
  
  const rowNumber = data.rowId;
  if (!rowNumber || rowNumber < 2) {
    return jsonResponse({ error: 'Invalid row ID' }, headers, 400);
  }
  
  sheet.getRange(rowNumber, 9).setValue('Cancelled');
  sheet.getRange(rowNumber, 10).setValue(data.reason || 'Cancelled by patient');
  
  return jsonResponse({ 
    success: true, 
    message: 'Appointment cancelled successfully!'
  }, headers);
}

/**
 * Get appointment statistics
 */
function getAppointmentStats(headers) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ 
      total: 0, 
      today: 0, 
      pending: 0,
      confirmed: 0,
      completed: 0
    }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const today = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  
  let total = 0;
  let todayCount = 0;
  let pending = 0;
  let confirmed = 0;
  let completed = 0;
  let cancelled = 0;
  
  for (let i = 1; i < data.length; i++) {
    total++;
    
    const apptDate = data[i][4] ? Utilities.formatDate(new Date(data[i][4]), 'Asia/Kolkata', 'yyyy-MM-dd') : '';
    if (apptDate === today) todayCount++;
    
    const status = data[i][8] || 'Pending';
    if (status === 'Pending') pending++;
    else if (status === 'Confirmed') confirmed++;
    else if (status === 'Completed') completed++;
    else if (status === 'Cancelled') cancelled++;
  }
  
  return jsonResponse({
    total: total,
    today: todayCount,
    pending: pending,
    confirmed: confirmed,
    completed: completed,
    cancelled: cancelled
  }, headers);
}

/**
 * Helper: Find existing appointment
 */
function findExistingAppointment(sheet, mobile, date) {
  if (!mobile || !date) return null;
  
  const data = sheet.getDataRange().getValues();
  const searchDate = Utilities.formatDate(new Date(date), 'Asia/Kolkata', 'yyyy-MM-dd');
  
  for (let i = 1; i < data.length; i++) {
    const rowMobile = data[i][2];
    const rowDate = data[i][4] ? Utilities.formatDate(new Date(data[i][4]), 'Asia/Kolkata', 'yyyy-MM-dd') : '';
    
    if (rowMobile === mobile && rowDate === searchDate) {
      return {
        rowId: i + 1,
        status: data[i][8]
      };
    }
  }
  
  return null;
}

/**
 * Helper: Get sheet by name
 */
function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(name);
}

/**
 * Helper: Get or create sheet
 */
function getOrCreateSheet(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (headers) {
      sheet.appendRow(headers);
      // Format header row
      sheet.getRange(1, 1, 1, headers.length)
        .setFontWeight('bold')
        .setBackground('#4285f4')
        .setFontColor('white');
    }
  }
  
  return sheet;
}

/**
 * Helper: Format date
 */
function formatDate(date) {
  if (!date) return '';
  const d = new Date(date);
  return Utilities.formatDate(d, 'Asia/Kolkata', 'yyyy-MM-dd');
}

/**
 * Helper: JSON response
 */
function jsonResponse(data, headers, statusCode) {
  const output = ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  
  // Set headers
  for (const [key, value] of Object.entries(headers)) {
    output.setHeader(key, value);
  }
  
  return output;
}

/**
 * Helper: Send confirmation
 */
function sendConfirmation(data) {
  try {
    // Send email to admin
    const adminEmail = 'your-email@example.com';
    const subject = 'New Appointment Booked - AN Clinic';
    const body = `
New appointment has been booked:

Patient: ${data.name}
Mobile: ${data.mobile}
Age: ${data.age || 'Not provided'}
Date: ${data.date}
Time: ${data.time || 'Not specified'}
Problem: ${data.problem || 'Not specified'}
Doctor: ${data.doctor || 'Any Available'}

Please confirm this appointment.
    `;
    
    MailApp.sendEmail(adminEmail, subject, body);
  } catch(e) {
    console.log('Confirmation email failed:', e);
  }
}

/**
 * ADMIN FUNCTIONS (Run these from Apps Script editor)
 */

/**
 * Confirm an appointment
 */
function confirmAppointment(rowNumber) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) return;
  
  sheet.getRange(rowNumber, 9).setValue('Confirmed');
  
  // Get patient details for SMS
  const mobile = sheet.getRange(rowNumber, 3).getValue();
  const name = sheet.getRange(rowNumber, 2).getValue();
  const date = sheet.getRange(rowNumber, 5).getValue();
  const time = sheet.getRange(rowNumber, 6).getValue();
  
  console.log(`Appointment confirmed for ${name} (${mobile}) on ${date} at ${time}`);
}

/**
 * Mark appointment as completed
 */
function completeAppointment(rowNumber) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) return;
  
  sheet.getRange(rowNumber, 9).setValue('Completed');
  console.log('Appointment marked as completed at row ' + rowNumber);
}

/**
 * Get pending confirmations
 */
function getPendingConfirmations() {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) return [];
  
  const data = sheet.getDataRange().getValues();
  const pending = [];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][8] === 'Pending') {
      pending.push({
        row: i + 1,
        name: data[i][1],
        mobile: data[i][2],
        date: formatDate(data[i][4]),
        time: data[i][5],
        problem: data[i][6]
      });
    }
  }
  
  console.log('Pending confirmations:', pending);
  return pending;
}

/**
 * Search appointments by mobile number
 */
function searchByMobile(mobile) {
  const sheet = getSheet(APPOINTMENT_SHEET_NAME);
  if (!sheet) return [];
  
  const data = sheet.getDataRange().getValues();
  const results = [];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][2] && data[i][2].toString().includes(mobile)) {
      results.push({
        row: i + 1,
        name: data[i][1],
        mobile: data[i][2],
        date: formatDate(data[i][4]),
        status: data[i][8]
      });
    }
  }
  
  console.log('Search results:', results);
  return results;
}
