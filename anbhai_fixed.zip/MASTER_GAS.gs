const SHEETS = {
  FEEDBACK: 'Feedback',
  ANNOUNCEMENTS: 'Announcements',
  APPOINTMENTS: 'Appointments',
  MEDICINE_ORDERS: 'MedicineOrders',
  SHOPPING_ORDERS: 'ShoppingOrders',
  MEDICINES: 'Medicines',
  GALLERY: 'Gallery',
  CONFIG: 'Config'
};

function doGet(e) {
  const action = e.parameter.action;
  try {
    switch(action) {
      case 'getFeedback':            return getFeedback();
      case 'getFeedbackStats':       return getFeedbackStats();
      case 'getAnnouncements':       return getAnnouncements();
      case 'getActiveAnnouncements': return getActiveAnnouncements();
      case 'getAppointments':        return getAppointments();
      case 'getTodayAppointments':   return getTodayAppointments();
      case 'getAppointmentStats':    return getAppointmentStats();
      case 'getOrders':              return getOrders();
      case 'getPendingOrders':       return getPendingOrders();
      case 'getOrderStats':          return getOrderStats();
      case 'getShoppingOrders':      return getShoppingOrders();
      case 'getMedicines':           return getMedicines();
      case 'getGallery':             return getGallery();
      case 'getPublicInfo':          return getPublicInfo();
      case 'getDashboard':           return getDashboardData();
      default:                       return jsonResponse({ error: 'Invalid action: ' + action });
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() });
  }
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const action = data.action;
    switch(action) {
      case 'submitFeedback':     return submitFeedback(data);
      case 'addAnnouncement':    return addAnnouncement(data);
      case 'updateAnnouncement': return updateAnnouncement(data);
      case 'appointment':
      case 'bookAppointment':    return bookAppointment(data);
      case 'updateAppointment':  return updateAppointment(data);
      case 'cancelAppointment':  return cancelAppointment(data);
      case 'medicineOrder':
      case 'placeOrder':         return placeOrder(data);
      case 'shoppingOrder':
      case 'placeShoppingOrder': return placeShoppingOrder(data);
      case 'updateOrder':        return updateOrder(data);
      case 'cancelOrder':        return cancelOrder(data);
      default:                   return jsonResponse({ error: 'Invalid action: ' + action });
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() });
  }
}

function doOptions(e) {
  return ContentService.createTextOutput('').setMimeType(ContentService.MimeType.JSON);
}

function getFeedback() {
  const sheet = getSheet(SHEETS.FEEDBACK);
  if (!sheet) return jsonResponse({ feedback: [] });
  const data = sheet.getDataRange().getValues();
  const feedback = [];
  for (let i = 1; i < data.length; i++) {
    if (data[i][6] !== 'Rejected') {
      feedback.push({ timestamp: formatDate(data[i][0]), name: data[i][1] || 'Anonymous', stars: parseInt(data[i][2]) || 5, text: data[i][3] || '', date: formatDate(data[i][0]) });
    }
  }
  return jsonResponse({ feedback: feedback.slice(0, 10) });
}

function getFeedbackStats() {
  const sheet = getSheet(SHEETS.FEEDBACK);
  if (!sheet) return jsonResponse({ total: 0, average: 0 });
  const data = sheet.getDataRange().getValues();
  let total = 0, sum = 0;
  for (let i = 1; i < data.length; i++) {
    const rating = parseInt(data[i][2]);
    if (rating) { total++; sum += rating; }
  }
  return jsonResponse({ total: total, average: total > 0 ? (sum / total).toFixed(1) : 0 });
}

function submitFeedback(data) {
  const sheet = getOrCreateSheet(SHEETS.FEEDBACK,
    ['Timestamp', 'Patient Name', 'Rating', 'Feedback Text', 'Phone', 'Email', 'Status', 'Reply']);
  sheet.appendRow([new Date(), data.name || 'Anonymous', data.rating || 5, data.text || '', data.phone || '', data.email || '', 'Pending', '']);
  return jsonResponse({ success: true, message: 'Thank you for your feedback!' });
}

function getAnnouncements() {
  const sheet = getSheet(SHEETS.ANNOUNCEMENTS);
  if (!sheet) return jsonResponse({ announcements: [] });
  const data = sheet.getDataRange().getValues();
  const announcements = [];
  for (let i = 1; i < data.length; i++) {
    announcements.push({ timestamp: formatDateTime(data[i][0]), title: data[i][1] || '', message: data[i][2] || '', imageUrl: data[i][3] || '', priority: data[i][4] || 'normal', active: data[i][5] || 'no', expiryDate: formatDate(data[i][6]), author: data[i][7] || '' });
  }
  return jsonResponse({ announcements: announcements });
}

function getActiveAnnouncements() {
  const sheet = getSheet(SHEETS.ANNOUNCEMENTS);
  if (!sheet) return jsonResponse({ announcements: [] });
  const data = sheet.getDataRange().getValues();
  const announcements = [];
  const now = new Date();
  for (let i = 1; i < data.length; i++) {
    if (data[i][5] !== 'yes') continue;
    if (data[i][6]) { const expiry = new Date(data[i][6]); if (expiry < now) continue; }
    announcements.push({ timestamp: formatDateTime(data[i][0]), title: data[i][1] || '', message: data[i][2] || '', imageUrl: data[i][3] || '', priority: data[i][4] || 'normal', active: data[i][5] || 'no' });
  }
  const priorityOrder = { high: 0, normal: 1, low: 2 };
  announcements.sort((a, b) => (priorityOrder[a.priority]||1) - (priorityOrder[b.priority]||1));
  return jsonResponse({ announcements: announcements });
}

function addAnnouncement(data) {
  const sheet = getOrCreateSheet(SHEETS.ANNOUNCEMENTS,
    ['Timestamp', 'Title', 'Message', 'ImageURL', 'Priority', 'Active', 'ExpiryDate', 'Author']);
  sheet.appendRow([new Date(), data.title || '', data.message || '', data.imageUrl || '', data.priority || 'normal', data.active || 'yes', data.expiryDate || '', data.author || 'Admin']);
  return jsonResponse({ success: true, message: 'Announcement added!' });
}

function updateAnnouncement(data) {
  const sheet = getSheet(SHEETS.ANNOUNCEMENTS);
  if (!sheet) return jsonResponse({ error: 'Sheet not found' });
  const row = data.rowId;
  if (data.title !== undefined) sheet.getRange(row, 2).setValue(data.title);
  if (data.message !== undefined) sheet.getRange(row, 3).setValue(data.message);
  if (data.active !== undefined) sheet.getRange(row, 6).setValue(data.active);
  return jsonResponse({ success: true, message: 'Announcement updated!' });
}

function bookAppointment(data) {
  const sheet = getOrCreateSheet(SHEETS.APPOINTMENTS,
    ['Timestamp', 'Name', 'Mobile', 'Age', 'Date', 'Time', 'Problem', 'Doctor', 'Status', 'Notes', 'UTR']);
  sheet.appendRow([new Date(), data.name || '', data.mobile || '', data.age || '', data.date || '', data.time || '', data.problem || '', data.doctor || 'Any Available', 'Pending', '', data.utr || '']);
  return jsonResponse({ success: true, message: 'Appointment booked! We will confirm within 2 hours.' });
}

function getAppointments() {
  const sheet = getSheet(SHEETS.APPOINTMENTS);
  if (!sheet) return jsonResponse({ appointments: [] });
  const data = sheet.getDataRange().getValues();
  const appointments = [];
  for (let i = 1; i < data.length; i++) {
    appointments.push({ timestamp: formatDateTime(data[i][0]), name: data[i][1] || '', mobile: data[i][2] || '', date: formatDate(data[i][4]), time: data[i][5] || '', problem: data[i][6] || '', doctor: data[i][7] || '', status: data[i][8] || 'Pending' });
  }
  return jsonResponse({ appointments: appointments });
}

function getTodayAppointments() {
  const sheet = getSheet(SHEETS.APPOINTMENTS);
  if (!sheet) return jsonResponse({ appointments: [], count: 0 });
  const data = sheet.getDataRange().getValues();
  const today = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  const appointments = [];
  for (let i = 1; i < data.length; i++) {
    const apptDate = data[i][4] ? Utilities.formatDate(new Date(data[i][4]), 'Asia/Kolkata', 'yyyy-MM-dd') : '';
    if (apptDate === today && data[i][8] !== 'Cancelled') {
      appointments.push({ name: data[i][1] || '', time: data[i][5] || '', status: data[i][8] || 'Pending' });
    }
  }
  return jsonResponse({ appointments: appointments, count: appointments.length });
}

function getAppointmentStats() {
  const sheet = getSheet(SHEETS.APPOINTMENTS);
  if (!sheet) return jsonResponse({ total: 0, today: 0, pending: 0 });
  const data = sheet.getDataRange().getValues();
  const today = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  let total = 0, todayCount = 0, pending = 0;
  for (let i = 1; i < data.length; i++) {
    total++;
    const apptDate = data[i][4] ? Utilities.formatDate(new Date(data[i][4]), 'Asia/Kolkata', 'yyyy-MM-dd') : '';
    if (apptDate === today) todayCount++;
    if (data[i][8] === 'Pending') pending++;
  }
  return jsonResponse({ total: total, today: todayCount, pending: pending });
}

function updateAppointment(data) {
  const sheet = getSheet(SHEETS.APPOINTMENTS);
  if (!sheet) return jsonResponse({ error: 'Sheet not found' });
  if (data.status !== undefined) sheet.getRange(data.rowId, 9).setValue(data.status);
  if (data.notes !== undefined) sheet.getRange(data.rowId, 10).setValue(data.notes);
  return jsonResponse({ success: true, message: 'Appointment updated!' });
}

function cancelAppointment(data) {
  const sheet = getSheet(SHEETS.APPOINTMENTS);
  if (!sheet) return jsonResponse({ error: 'Sheet not found' });
  sheet.getRange(data.rowId, 9).setValue('Cancelled');
  sheet.getRange(data.rowId, 10).setValue(data.reason || 'Cancelled by patient');
  return jsonResponse({ success: true, message: 'Appointment cancelled!' });
}

function placeOrder(data) {
  const sheet = getOrCreateSheet(SHEETS.MEDICINE_ORDERS,
    ['Timestamp', 'Name', 'Phone', 'Address', 'Distance', 'Medicine', 'DeliveryCharge', 'Payment', 'UTR', 'PrescriptionImg', 'Status', 'Notes']);
  if (!data.name || !data.phone || !data.address) return jsonResponse({ success: false, message: 'Name, phone and address required' });
  sheet.appendRow([new Date(), data.name, data.phone, data.address, data.distanceKm || '', data.medicine || '', data.deliveryCharge || '', data.payMethod || 'Cash on Delivery', data.utr || '', data.prescriptionImg || '', 'Pending', '']);
  return jsonResponse({ success: true, message: 'Order placed! We will call you to confirm.' });
}

function placeShoppingOrder(data) {
  const sheet = getOrCreateSheet(SHEETS.SHOPPING_ORDERS, [
    'Timestamp', 'Name', 'Phone', 'AltPhone', 'Address', 'Landmark', 'City', 'PIN', 'DistanceKm',
    'MedicineList', 'MedicineImageURLs', 'Quantity', 'Notes', 'TreatmentSource', 'PaymentMethod',
    'UTR', 'PrescriptionImgUrl', 'PaymentImgUrl', 'DeliveryCharge', 'Status'
  ]);
  if (!data.name || !data.phone || !data.address || !data.city || !data.pinCode || !data.medicine) {
    return jsonResponse({ success: false, message: 'Required fields are missing' });
  }
  sheet.appendRow([
    new Date(),
    data.name || '',
    data.phone || '',
    data.altPhone || '',
    data.address || '',
    data.landmark || '',
    data.city || '',
    data.pinCode || '',
    data.distanceKm || '',
    data.medicine || '',
    data.medicineImages || '',
    data.quantity || '',
    data.notes || '',
    data.treatmentSource || '',
    data.payMethod || 'Cash on Delivery',
    data.utr || '',
    data.prescriptionImg || '',
    data.paymentImg || '',
    data.deliveryCharge || '',
    'Pending'
  ]);
  return jsonResponse({ success: true, message: 'Shopping order saved successfully!' });
}

function getOrders() {
  const sheet = getSheet(SHEETS.MEDICINE_ORDERS);
  if (!sheet) return jsonResponse({ orders: [] });
  const data = sheet.getDataRange().getValues();
  const orders = [];
  for (let i = 1; i < data.length; i++) {
    orders.push({ timestamp: formatDateTime(data[i][0]), name: data[i][1] || '', phone: data[i][2] || '', address: data[i][3] || '', medicine: data[i][5] || '', deliveryCharge: data[i][6] || '', status: data[i][10] || 'Pending' });
  }
  return jsonResponse({ orders: orders });
}

function getPendingOrders() {
  const sheet = getSheet(SHEETS.MEDICINE_ORDERS);
  if (!sheet) return jsonResponse({ orders: [], count: 0 });
  const data = sheet.getDataRange().getValues();
  const pendingStatuses = ['Pending', 'Confirmed', 'Processing', 'Out for Delivery'];
  const orders = [];
  for (let i = 1; i < data.length; i++) {
    if (pendingStatuses.includes(data[i][10])) orders.push({ name: data[i][1] || '', phone: data[i][2] || '', status: data[i][10] || 'Pending' });
  }
  return jsonResponse({ orders: orders, count: orders.length });
}

function getShoppingOrders() {
  const sheet = getSheet(SHEETS.SHOPPING_ORDERS);
  if (!sheet) return jsonResponse({ orders: [] });

  const data = sheet.getDataRange().getValues();
  const orders = [];
  for (let i = 1; i < data.length; i++) {
    orders.push({
      timestamp: formatDateTime(data[i][0]),
      name: data[i][1] || '',
      phone: data[i][2] || '',
      city: data[i][6] || '',
      medicine: data[i][9] || '',
      prescriptionImg: data[i][16] || '',
      paymentImg: data[i][17] || '',
      status: data[i][19] || 'Pending'
    });
  }
  return jsonResponse({ orders: orders });
}

function getMedicines() {
  ensureSeedData_();
  const sheet = getOrCreateSheet(SHEETS.MEDICINES, ['Timestamp', 'Name', 'ImageURL', 'Category', 'Description', 'Available', 'Price']);
  const data = sheet.getDataRange().getValues();
  const medicines = [];
  for (let i = 1; i < data.length; i++) {
    medicines.push({
      name: data[i][1] || '',
      imageUrl: data[i][2] || '',
      category: data[i][3] || 'general',
      description: data[i][4] || '',
      available: String(data[i][5] || 'Yes').toLowerCase() !== 'no',
      price: data[i][6] || ''
    });
  }
  return jsonResponse({ medicines: medicines });
}

function getGallery() {
  ensureSeedData_();
  const sheet = getOrCreateSheet(SHEETS.GALLERY, ['Timestamp', 'Title', 'Caption', 'ImageURL', 'Active', 'Order', 'Icon']);
  const data = sheet.getDataRange().getValues();
  const gallery = [];
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][4] || 'yes').toLowerCase() === 'no') continue;
    gallery.push({
      title: data[i][1] || '',
      caption: data[i][2] || '',
      imageUrl: data[i][3] || '',
      icon: data[i][6] || 'fa-image',
      order: Number(data[i][5]) || i
    });
  }
  gallery.sort((a, b) => a.order - b.order);
  return jsonResponse({ gallery: gallery });
}

function ensureSeedData_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  let medicineSheet = ss.getSheetByName(SHEETS.MEDICINES);
  if (!medicineSheet) medicineSheet = ss.insertSheet(SHEETS.MEDICINES);
  if (medicineSheet.getLastRow() === 0) {
    medicineSheet.appendRow(['Timestamp', 'Name', 'ImageURL', 'Category', 'Description', 'Available', 'Price']);
    [
      ['','Paracetamol 500mg','','fever','For fever and mild pain relief','Yes',''],
      ['','Ibuprofen 400mg','','pain','Anti-inflammatory pain relief','Yes',''],
      ['','Pantoprazole','','stomach','Acidity and stomach protection','Yes',''],
      ['','Cetirizine 10mg','','fever','Allergy and cold relief','Yes',''],
      ['','Vitamin D3 1000IU','','vitamins','Bone health and immunity','Yes',''],
      ['','ORS Sachet','','stomach','Oral rehydration for dehydration','Yes',''],
      ['','Bandage Roll','','firstaid','Sterile cotton bandage roll','Yes',''],
      ['','Dolo 650','','fever','Paracetamol for high fever','Yes',''],
      ['','Calcium + D3','','vitamins','Bone strength supplement','Yes',''],
      ['','Antacid Syrup','','stomach','For acidity and gas relief','Yes',''],
      ['','Doctor Prescribed','','prescribed','Upload your prescription for any doctor-prescribed medicine','Yes',''],
      ['','Crepe Bandage','','firstaid','For joint support and sprains','Yes','']
    ].forEach(row => medicineSheet.appendRow(row));
  }

  let gallerySheet = ss.getSheetByName(SHEETS.GALLERY);
  if (!gallerySheet) gallerySheet = ss.insertSheet(SHEETS.GALLERY);
  if (gallerySheet.getLastRow() === 0) {
    gallerySheet.appendRow(['Timestamp', 'Title', 'Caption', 'ImageURL', 'Active', 'Order', 'Icon']);
    [
      ['','Reception','Warm welcome for every patient','','Yes',1,'fa-hospital'],
      ['','X-Ray Room','Digital radiography for precise diagnosis','','Yes',2,'fa-x-ray'],
      ['','Physio Hall','Advanced rehabilitation equipment','','Yes',3,'fa-person-walking'],
      ['','Treatment Room','Sterile and fully equipped treatment area','','Yes',4,'fa-bed-pulse'],
      ['','Rehab Area','Recovery and strength training zone','','Yes',5,'fa-dumbbell'],
      ['','Consultation','Private, comfortable consultation rooms','','Yes',6,'fa-stethoscope'],
      ['','Pharmacy','In-house pharmacy for convenience','','Yes',7,'fa-pills'],
      ['','Lab','In-house diagnostic laboratory','','Yes',8,'fa-microscope'],
      ['','Clinic Front','Easily accessible main entrance','','Yes',9,'fa-building-columns']
    ].forEach(row => gallerySheet.appendRow(row));
  }
}

function getOrderStats() {function getOrderStats() {
  const sheet = getSheet(SHEETS.MEDICINE_ORDERS);
  if (!sheet) return jsonResponse({ total: 0, pending: 0, delivered: 0 });
  const data = sheet.getDataRange().getValues();
  let total = 0, pending = 0, delivered = 0;
  for (let i = 1; i < data.length; i++) {
    total++;
    if (data[i][10] === 'Pending') pending++;
    if (data[i][10] === 'Delivered') delivered++;
  }
  return jsonResponse({ total: total, pending: pending, delivered: delivered });
}

function updateOrder(data) {
  const sheet = getSheet(SHEETS.MEDICINE_ORDERS);
  if (!sheet) return jsonResponse({ error: 'Sheet not found' });
  if (data.status !== undefined) sheet.getRange(data.rowId, 11).setValue(data.status);
  if (data.notes !== undefined) sheet.getRange(data.rowId, 12).setValue(data.notes);
  return jsonResponse({ success: true, message: 'Order updated!' });
}

function cancelOrder(data) {
  const sheet = getSheet(SHEETS.MEDICINE_ORDERS);
  if (!sheet) return jsonResponse({ error: 'Sheet not found' });
  sheet.getRange(data.rowId, 11).setValue('Cancelled');
  sheet.getRange(data.rowId, 12).setValue(data.reason || 'Cancelled by customer');
  return jsonResponse({ success: true, message: 'Order cancelled!' });
}

function placeShoppingOrder(data) {
  const sheet = getOrCreateSheet(SHEETS.SHOPPING_ORDERS,
    ['Timestamp', 'Name', 'Phone', 'AltPhone', 'Address', 'Landmark', 'City', 'PinCode',
     'Medicine', 'Quantity', 'Notes', 'DistanceKm', 'TreatmentSource', 'PayMethod',
     'UTR', 'PrescriptionImg', 'PaymentImg', 'DeliveryCharge', 'Status']);
  if (!data.name || !data.phone || !data.address) return jsonResponse({ success: false, message: 'Name, phone and address required' });
  sheet.appendRow([
    new Date(),
    data.name,
    data.phone,
    data.altPhone || '',
    data.address,
    data.landmark || '',
    data.city || '',
    data.pinCode || '',
    data.medicine || '',
    data.quantity || '',
    data.notes || '',
    data.distanceKm || '',
    data.treatmentSource || '',
    data.payMethod || 'Cash on Delivery',
    data.utr || '',
    data.prescriptionImg || '',
    data.paymentImg || '',
    data.deliveryCharge || '',
    'Pending'
  ]);
  return jsonResponse({ success: true, message: 'Shopping order placed! We will call you to confirm.' });
}

function getShoppingOrders() {
  const sheet = getSheet(SHEETS.SHOPPING_ORDERS);
  if (!sheet) return jsonResponse({ orders: [] });
  const data = sheet.getDataRange().getValues();
  const orders = [];
  for (let i = 1; i < data.length; i++) {
    orders.push({ timestamp: formatDateTime(data[i][0]), name: data[i][1] || '', phone: data[i][2] || '', city: data[i][6] || '', medicine: data[i][8] || '', payMethod: data[i][13] || '', status: data[i][18] || 'Pending' });
  }
  return jsonResponse({ orders: orders });
}

function getPublicInfo() {
  const config = getConfig();
  return jsonResponse({
    phone:   config.phone   || '7766953200',
    email:   config.email   || 'clinic@example.com',
    address: config.address || 'AN Clinic, Main Road, Bihar',
    mapSrc:  config.mapSrc  || 'https://maps.google.com/maps?q=Bihar,India&output=embed&z=13',
    dirLink: config.dirLink || 'https://maps.google.com/?q=AN+Fractures+Physiotherapist+Bihar',
    upi:     config.upi     || 'Contact clinic for UPI ID',
    hours:   'Mon-Sat: 9 AM - 7 PM  |  Sun: 9 AM - 1 PM'
  });
}

function getDashboardData() {
  let todayCount = 0;
  try {
    const apptSheet = getSheet(SHEETS.APPOINTMENTS);
    if (apptSheet) {
      const apptData = apptSheet.getDataRange().getValues();
      const today = Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
      for (let i = 1; i < apptData.length; i++) {
        const d = apptData[i][4] ? Utilities.formatDate(new Date(apptData[i][4]), 'Asia/Kolkata', 'yyyy-MM-dd') : '';
        if (d === today && apptData[i][8] !== 'Cancelled') todayCount++;
      }
    }
  } catch(e) {}

  let pendingCount = 0;
  try {
    const ordSheet = getSheet(SHEETS.MEDICINE_ORDERS);
    if (ordSheet) {
      const ordData = ordSheet.getDataRange().getValues();
      const pendingStatuses = ['Pending', 'Confirmed', 'Processing', 'Out for Delivery'];
      for (let i = 1; i < ordData.length; i++) {
        if (pendingStatuses.includes(ordData[i][10])) pendingCount++;
      }
    }
  } catch(e) {}

  let shopPending = 0;
  try {
    const shopSheet = getSheet(SHEETS.SHOPPING_ORDERS);
    if (shopSheet) {
      const shopData = shopSheet.getDataRange().getValues();
      for (let i = 1; i < shopData.length; i++) {
        if (shopData[i][18] === 'Pending') shopPending++;
      }
    }
  } catch(e) {}

  let avgRating = '4.8';
  try {
    const fbSheet = getSheet(SHEETS.FEEDBACK);
    if (fbSheet) {
      const fbData = fbSheet.getDataRange().getValues();
      let total = 0, sum = 0;
      for (let i = 1; i < fbData.length; i++) {
        const r = parseInt(fbData[i][2]);
        if (r) { total++; sum += r; }
      }
      if (total > 0) avgRating = (sum / total).toFixed(1);
    }
  } catch(e) {}

  let totalPatients = 5247;
  try {
    const apptSheet = getSheet(SHEETS.APPOINTMENTS);
    if (apptSheet) {
      const count = apptSheet.getLastRow() - 1;
      if (count > 0) totalPatients = Math.max(5247, count);
    }
  } catch(e) {}

  return jsonResponse({
    todayAppt: todayCount,
    pendingOrders: pendingCount + shopPending,
    totalPatients: totalPatients,
    avgRating: avgRating
  });
}

function getSheet(name) {
  return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
}

function getOrCreateSheet(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (headers) {
      sheet.appendRow(headers);
      sheet.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#4285f4').setFontColor('white');
    }
  }
  return sheet;
}

function getConfig() {
  const sheet = getSheet(SHEETS.CONFIG);
  if (!sheet) return {};
  const data = sheet.getDataRange().getValues();
  const config = {};
  for (let i = 1; i < data.length; i++) { config[data[i][0]] = data[i][1]; }
  return config;
}

function formatDate(date) {
  if (!date) return '';
  try { return Utilities.formatDate(new Date(date), 'Asia/Kolkata', 'yyyy-MM-dd'); } catch(e) { return ''; }
}

function formatDateTime(date) {
  if (!date) return '';
  try { return Utilities.formatDate(new Date(date), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss'); } catch(e) { return ''; }
}

function jsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}

function setupSheets() {
  getOrCreateSheet(SHEETS.FEEDBACK,        ['Timestamp', 'Patient Name', 'Rating', 'Feedback Text', 'Phone', 'Email', 'Status', 'Reply']);
  getOrCreateSheet(SHEETS.ANNOUNCEMENTS,   ['Timestamp', 'Title', 'Message', 'ImageURL', 'Priority', 'Active', 'ExpiryDate', 'Author']);
  getOrCreateSheet(SHEETS.APPOINTMENTS,    ['Timestamp', 'Name', 'Mobile', 'Age', 'Date', 'Time', 'Problem', 'Doctor', 'Status', 'Notes', 'UTR']);
  getOrCreateSheet(SHEETS.MEDICINE_ORDERS, ['Timestamp', 'Name', 'Phone', 'Address', 'Distance', 'Medicine', 'DeliveryCharge', 'Payment', 'UTR', 'PrescriptionImg', 'Status', 'Notes']);
  getOrCreateSheet(SHEETS.SHOPPING_ORDERS, ['Timestamp', 'Name', 'Phone', 'AltPhone', 'Address', 'Landmark', 'City', 'PinCode', 'Medicine', 'Quantity', 'Notes', 'DistanceKm', 'TreatmentSource', 'PayMethod', 'UTR', 'PrescriptionImg', 'PaymentImg', 'DeliveryCharge', 'Status']);
  getOrCreateSheet(SHEETS.CONFIG,          ['Key', 'Value']);
  Logger.log('All sheets created successfully!');
}

function addConfigValues() {
  const sheet = getOrCreateSheet(SHEETS.CONFIG, ['Key', 'Value']);
  const defaults = [
    ['phone',   '7766953200'],
    ['email',   'clinic@example.com'],
    ['address', 'AN Clinic, Main Road, Bihar'],
    ['mapSrc',  'https://maps.google.com/maps?q=Bihar,India&output=embed&z=13'],
    ['dirLink', 'https://maps.google.com/?q=AN+Fractures+Physiotherapist+Bihar'],
    ['upi',     'clinic@upi']
  ];
  defaults.forEach(([key, value]) => sheet.appendRow([key, value]));
  Logger.log('Default config values added!');
}
