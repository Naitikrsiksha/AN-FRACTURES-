/**
 * ================================================================
 *  GOOGLE APPS SCRIPT - SHOPPING (MEDICINE ORDER) SHEET
 *  AN Clinic - Medicine Order Management System
 * ================================================================
 * 
 * SHEET STRUCTURE (Create a Google Sheet with these columns):
 * | Timestamp | Name | Phone | Address | Distance | Medicine | DeliveryCharge | Payment | UTR | PrescriptionImg | Status | Notes |
 * 
 * STATUS OPTIONS: Pending, Confirmed, Processing, Out for Delivery, Delivered, Cancelled
 * 
 * DEPLOYMENT INSTRUCTIONS:
 * 1. Create a new Google Sheet
 * 2. Add headers in Row 1 as shown above
 * 3. Go to Extensions > Apps Script
 * 4. Delete default code and paste this entire script
 * 5. Save the project (Ctrl+S)
 * 6. Click Deploy > New Deployment
 * 7. Select Type: Web App
 * 8. Execute as: Me
 * 9. Who has access: Anyone
 * 10. Click Deploy and copy the Web App URL
 * 11. Use this URL in your website's BACKEND_URL for medicine order actions
 */

// Sheet name for medicine orders
const MEDICINE_SHEET_NAME = 'MedicineOrders';
const SHOPPING_SHEET_NAME = 'ShoppingOrders';
const MEDICINES_SHEET_NAME = 'Medicines';
const GALLERY_SHEET_NAME = 'Gallery';

/**
 * Main entry point for web requests
 */
function doGet(e) {
  const action = e.parameter.action;
  
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    switch(action) {
      case 'getOrders':
        return getOrders(headers);
      case 'getPendingOrders':
        return getPendingOrders(headers);
      case 'getStats':
        return getOrderStats(headers);
      case 'getShoppingOrders':
        return getShoppingOrders(headers);
      case 'getMedicines':
        return getMedicines(headers);
      case 'getGallery':
        return getGallery(headers);
      default:
        return jsonResponse({ error: 'Invalid action' }, headers, 400);
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle POST requests
 */
function doPost(e) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  
  try {
    const data = JSON.parse(e.postData.contents);
    
    switch(data.action) {
      case 'medicineOrder':
      case 'placeOrder':
        return placeOrder(data, headers);
      case 'shoppingOrder':
      case 'placeShoppingOrder':
        return placeShoppingOrder(data, headers);
      case 'updateOrder':
        return updateOrder(data, headers);
      case 'cancelOrder':
        return cancelOrder(data, headers);
      default:
        return jsonResponse({ error: 'Invalid action' }, headers, 400);
    }
  } catch(error) {
    return jsonResponse({ error: error.toString() }, headers, 500);
  }
}

/**
 * Handle OPTIONS for CORS preflight
 */
function doOptions(e) {
  return ContentService.createTextOutput()
    .setHeaders({
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
}

/**
 * Place new medicine order
 */
function placeOrder(data, headers) {
  const sheet = getOrCreateSheet(MEDICINE_SHEET_NAME, 
    ['Timestamp', 'Name', 'Phone', 'Address', 'Distance', 'Medicine', 'DeliveryCharge', 'Payment', 'UTR', 'PrescriptionImg', 'Status', 'Notes']);

  if (!data.name || !data.phone || !data.address) {
    return jsonResponse({ 
      success: false, 
      message: 'Name, phone and address are required'
    }, headers, 400);
  }

  const timestamp = new Date();
  const row = [
    timestamp,
    data.name || '',
    data.phone || '',
    data.address || '',
    data.distanceKm || '',
    data.medicine || '',
    data.deliveryCharge || '',
    data.payMethod || 'Cash on Delivery',
    data.utr || '',
    data.prescriptionImg || '',
    'Pending',
    ''
  ];

  sheet.appendRow(row);

  return jsonResponse({ 
    success: true, 
    message: 'Order placed successfully! We will call you to confirm.',
    orderId: timestamp.getTime()
  }, headers);
}

function placeShoppingOrder(data, headers) {
  const sheet = getOrCreateSheet(SHOPPING_SHEET_NAME, [
    'Timestamp', 'Name', 'Phone', 'AltPhone', 'Address', 'Landmark', 'City', 'PIN', 'DistanceKm',
    'MedicineList', 'MedicineImageURLs', 'Quantity', 'Notes', 'TreatmentSource', 'PaymentMethod',
    'UTR', 'PrescriptionImgUrl', 'PaymentImgUrl', 'DeliveryCharge', 'Status'
  ]);

  if (!data.name || !data.phone || !data.address || !data.city || !data.pinCode || !data.medicine) {
    return jsonResponse({ success: false, message: 'Required fields are missing' }, headers, 400);
  }

  sheet.appendRow([
    new Date(),
    data.name || '',
    data.phone || '',
    data.altPhone || '',
    data.address || '',
    data.landmark || '',
    data.city || '',
    data.pinCode || '',
    data.distanceKm || '',
    data.medicine || '',
    data.medicineImages || '',
    data.quantity || '',
    data.notes || '',
    data.treatmentSource || '',
    data.payMethod || 'Cash on Delivery',
    data.utr || '',
    data.prescriptionImg || '',
    data.paymentImg || '',
    data.deliveryCharge || '',
    'Pending'
  ]);

  return jsonResponse({ success: true, message: 'Shopping order saved successfully!' }, headers);
}

function getOrders(headers) {
function getOrders(headers) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ orders: [] }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const orders = [];
  
  // Start from row 2 (skip header)
  for (let i = 1; i < data.length; i++) {
    orders.push({
      rowId: i + 1,
      timestamp: formatDateTime(data[i][0]),
      name: data[i][1] || '',
      phone: data[i][2] || '',
      address: data[i][3] || '',
      distance: data[i][4] || '',
      medicine: data[i][5] || '',
      deliveryCharge: data[i][6] || '',
      payment: data[i][7] || '',
      utr: data[i][8] || '',
      prescriptionImg: data[i][9] || '',
      status: data[i][10] || 'Pending',
      notes: data[i][11] || ''
    });
  }
  
  // Sort by timestamp (newest first)
  orders.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  return jsonResponse({ orders: orders }, headers);
}

/**
 * Get pending orders
 */
function getPendingOrders(headers) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ orders: [], count: 0 }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  const orders = [];
  
  const pendingStatuses = ['Pending', 'Confirmed', 'Processing', 'Out for Delivery'];
  
  for (let i = 1; i < data.length; i++) {
    if (pendingStatuses.includes(data[i][10])) {
      orders.push({
        rowId: i + 1,
        timestamp: formatDateTime(data[i][0]),
        name: data[i][1] || '',
        phone: data[i][2] || '',
        address: data[i][3] || '',
        distance: data[i][4] || '',
        medicine: data[i][5] || '',
        deliveryCharge: data[i][6] || '',
        status: data[i][10] || 'Pending'
      });
    }
  }
  
  return jsonResponse({ 
    orders: orders, 
    count: orders.length 
  }, headers);
}

/**
 * Update order status
 */
function updateOrder(data, headers) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ error: 'Sheet not found' }, headers, 404);
  }
  
  const rowNumber = data.rowId;
  if (!rowNumber || rowNumber < 2) {
    return jsonResponse({ error: 'Invalid row ID' }, headers, 400);
  }
  
  // Update fields
  if (data.status !== undefined) sheet.getRange(rowNumber, 11).setValue(data.status);
  if (data.notes !== undefined) sheet.getRange(rowNumber, 12).setValue(data.notes);
  if (data.utr !== undefined) sheet.getRange(rowNumber, 9).setValue(data.utr);
  
  return jsonResponse({ 
    success: true, 
    message: 'Order updated successfully!'
  }, headers);
}

/**
 * Cancel order
 */
function cancelOrder(data, headers) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ error: 'Sheet not found' }, headers, 404);
  }
  
  const rowNumber = data.rowId;
  if (!rowNumber || rowNumber < 2) {
    return jsonResponse({ error: 'Invalid row ID' }, headers, 400);
  }
  
  sheet.getRange(rowNumber, 11).setValue('Cancelled');
  sheet.getRange(rowNumber, 12).setValue(data.reason || 'Cancelled by customer');
  
  return jsonResponse({ 
    success: true, 
    message: 'Order cancelled successfully!'
  }, headers);
}

/**
 * Get order statistics
 */
function getShoppingOrders(headers) {
  const sheet = getSheet(SHOPPING_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ orders: [] }, headers);
  }

  const data = sheet.getDataRange().getValues();
  const orders = [];
  for (let i = 1; i < data.length; i++) {
    orders.push({
      timestamp: formatDateTime(data[i][0]),
      name: data[i][1] || '',
      phone: data[i][2] || '',
      city: data[i][6] || '',
      medicine: data[i][9] || '',
      prescriptionImg: data[i][16] || '',
      paymentImg: data[i][17] || '',
      status: data[i][19] || 'Pending'
    });
  }
  return jsonResponse({ orders: orders }, headers);
}

function getMedicines(headers) {
  ensureSeedData_();
  const sheet = getOrCreateSheet(MEDICINES_SHEET_NAME, ['Timestamp', 'Name', 'ImageURL', 'Category', 'Description', 'Available', 'Price']);
  const data = sheet.getDataRange().getValues();
  const medicines = [];
  for (let i = 1; i < data.length; i++) {
    medicines.push({
      name: data[i][1] || '',
      imageUrl: data[i][2] || '',
      category: data[i][3] || 'general',
      description: data[i][4] || '',
      available: String(data[i][5] || 'Yes').toLowerCase() !== 'no',
      price: data[i][6] || ''
    });
  }
  return jsonResponse({ medicines: medicines }, headers);
}

function getGallery(headers) {
  ensureSeedData_();
  const sheet = getOrCreateSheet(GALLERY_SHEET_NAME, ['Timestamp', 'Title', 'Caption', 'ImageURL', 'Active', 'Order', 'Icon']);
  const data = sheet.getDataRange().getValues();
  const gallery = [];
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][4] || 'yes').toLowerCase() === 'no') continue;
    gallery.push({
      title: data[i][1] || '',
      caption: data[i][2] || '',
      imageUrl: data[i][3] || '',
      icon: data[i][6] || 'fa-image',
      order: Number(data[i][5]) || i
    });
  }
  gallery.sort((a, b) => a.order - b.order);
  return jsonResponse({ gallery: gallery }, headers);
}

function ensureSeedData_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  let medicineSheet = ss.getSheetByName(MEDICINES_SHEET_NAME);
  if (!medicineSheet) medicineSheet = ss.insertSheet(MEDICINES_SHEET_NAME);
  if (medicineSheet.getLastRow() === 0) {
    medicineSheet.appendRow(['Timestamp', 'Name', 'ImageURL', 'Category', 'Description', 'Available', 'Price']);
    [
      ['','Paracetamol 500mg','','fever','For fever and mild pain relief','Yes',''],
      ['','Ibuprofen 400mg','','pain','Anti-inflammatory pain relief','Yes',''],
      ['','Pantoprazole','','stomach','Acidity and stomach protection','Yes',''],
      ['','Cetirizine 10mg','','fever','Allergy and cold relief','Yes',''],
      ['','Vitamin D3 1000IU','','vitamins','Bone health and immunity','Yes',''],
      ['','ORS Sachet','','stomach','Oral rehydration for dehydration','Yes',''],
      ['','Bandage Roll','','firstaid','Sterile cotton bandage roll','Yes',''],
      ['','Dolo 650','','fever','Paracetamol for high fever','Yes',''],
      ['','Calcium + D3','','vitamins','Bone strength supplement','Yes',''],
      ['','Antacid Syrup','','stomach','For acidity and gas relief','Yes',''],
      ['','Doctor Prescribed','','prescribed','Upload your prescription for any doctor-prescribed medicine','Yes',''],
      ['','Crepe Bandage','','firstaid','For joint support and sprains','Yes','']
    ].forEach(row => medicineSheet.appendRow(row));
  }

  let gallerySheet = ss.getSheetByName(GALLERY_SHEET_NAME);
  if (!gallerySheet) gallerySheet = ss.insertSheet(GALLERY_SHEET_NAME);
  if (gallerySheet.getLastRow() === 0) {
    gallerySheet.appendRow(['Timestamp', 'Title', 'Caption', 'ImageURL', 'Active', 'Order', 'Icon']);
    [
      ['','Reception','Warm welcome for every patient','','Yes',1,'fa-hospital'],
      ['','X-Ray Room','Digital radiography for precise diagnosis','','Yes',2,'fa-x-ray'],
      ['','Physio Hall','Advanced rehabilitation equipment','','Yes',3,'fa-person-walking'],
      ['','Treatment Room','Sterile and fully equipped treatment area','','Yes',4,'fa-bed-pulse'],
      ['','Rehab Area','Recovery and strength training zone','','Yes',5,'fa-dumbbell'],
      ['','Consultation','Private, comfortable consultation rooms','','Yes',6,'fa-stethoscope'],
      ['','Pharmacy','In-house pharmacy for convenience','','Yes',7,'fa-pills'],
      ['','Lab','In-house diagnostic laboratory','','Yes',8,'fa-microscope'],
      ['','Clinic Front','Easily accessible main entrance','','Yes',9,'fa-building-columns']
    ].forEach(row => gallerySheet.appendRow(row));
  }
}

function getOrderStats(headers) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) {
    return jsonResponse({ 
      total: 0, 
      pending: 0,
      delivered: 0,
      cancelled: 0
    }, headers);
  }
  
  const data = sheet.getDataRange().getValues();
  
  let total = 0;
  let pending = 0;
  let confirmed = 0;
  let processing = 0;
  let outForDelivery = 0;
  let delivered = 0;
  let cancelled = 0;
  
  for (let i = 1; i < data.length; i++) {
    total++;
    
    const status = data[i][10] || 'Pending';
    switch(status) {
      case 'Pending': pending++; break;
      case 'Confirmed': confirmed++; break;
      case 'Processing': processing++; break;
      case 'Out for Delivery': outForDelivery++; break;
      case 'Delivered': delivered++; break;
      case 'Cancelled': cancelled++; break;
    }
  }
  
  return jsonResponse({
    total: total,
    pending: pending,
    confirmed: confirmed,
    processing: processing,
    outForDelivery: outForDelivery,
    delivered: delivered,
    cancelled: cancelled
  }, headers);
}

/**
 * Helper: Get sheet by name
 */
function getSheet(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(name);
}

/**
 * Helper: Get or create sheet
 */
function getOrCreateSheet(name, headers) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);
  
  if (!sheet) {
    sheet = ss.insertSheet(name);
    if (headers) {
      sheet.appendRow(headers);
      // Format header row
      sheet.getRange(1, 1, 1, headers.length)
        .setFontWeight('bold')
        .setBackground('#10b981')
        .setFontColor('white');
    }
  }
  
  return sheet;
}

/**
 * Helper: Format date and time
 */
function formatDateTime(date) {
  if (!date) return '';
  const d = new Date(date);
  return Utilities.formatDate(d, 'Asia/Kolkata', 'yyyy-MM-dd HH:mm:ss');
}

/**
 * Helper: JSON response
 */
function jsonResponse(data, headers, statusCode) {
  const output = ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
  
  // Set headers
  for (const [key, value] of Object.entries(headers)) {
    output.setHeader(key, value);
  }
  
  return output;
}

/**
 * Helper: Send order notification
 */
function sendOrderNotification(data) {
  try {
    // Send email to admin
    const adminEmail = 'your-email@example.com';
    const subject = 'New Medicine Order - AN Clinic';
    const body = `
New medicine order has been placed:

Customer: ${data.name}
Phone: ${data.phone}
Address: ${data.address}
Distance: ${data.distanceKm || 'Not specified'} km
Medicine: ${data.medicine || 'Not specified'}
Delivery Charge: ${data.deliveryCharge || 'To be calculated'}
Payment: ${data.payMethod || 'Cash on Delivery'}

Please confirm this order.
    `;
    
    MailApp.sendEmail(adminEmail, subject, body);
  } catch(e) {
    console.log('Order notification email failed:', e);
  }
}

/**
 * ADMIN FUNCTIONS (Run these from Apps Script editor)
 */

/**
 * Confirm an order
 */
function confirmOrder(rowNumber) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) return;
  
  sheet.getRange(rowNumber, 11).setValue('Confirmed');
  
  const name = sheet.getRange(rowNumber, 2).getValue();
  const phone = sheet.getRange(rowNumber, 3).getValue();
  
  console.log(`Order confirmed for ${name} (${phone})`);
}

/**
 * Mark order as out for delivery
 */
function markOutForDelivery(rowNumber) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) return;
  
  sheet.getRange(rowNumber, 11).setValue('Out for Delivery');
  console.log('Order marked as out for delivery at row ' + rowNumber);
}

/**
 * Mark order as delivered
 */
function markDelivered(rowNumber) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) return;
  
  sheet.getRange(rowNumber, 11).setValue('Delivered');
  sheet.getRange(rowNumber, 12).setValue('Delivered on ' + Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd HH:mm'));
  
  console.log('Order marked as delivered at row ' + rowNumber);
}

/**
 * Get orders by status
 */
function getOrdersByStatus(status) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) return [];
  
  const data = sheet.getDataRange().getValues();
  const orders = [];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][10] === status) {
      orders.push({
        row: i + 1,
        name: data[i][1],
        phone: data[i][2],
        address: data[i][3],
        medicine: data[i][5],
        status: data[i][10]
      });
    }
  }
  
  console.log(`${status} orders:`, orders);
  return orders;
}

/**
 * Search orders by phone number
 */
function searchByPhone(phone) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) return [];
  
  const data = sheet.getDataRange().getValues();
  const results = [];
  
  for (let i = 1; i < data.length; i++) {
    if (data[i][2] && data[i][2].toString().includes(phone)) {
      results.push({
        row: i + 1,
        name: data[i][1],
        phone: data[i][2],
        medicine: data[i][5],
        status: data[i][10]
      });
    }
  }
  
  console.log('Search results:', results);
  return results;
}

/**
 * Calculate daily revenue
 */
function calculateDailyRevenue(date) {
  const sheet = getSheet(MEDICINE_SHEET_NAME);
  if (!sheet) return 0;
  
  const searchDate = date || Utilities.formatDate(new Date(), 'Asia/Kolkata', 'yyyy-MM-dd');
  const data = sheet.getDataRange().getValues();
  
  let totalRevenue = 0;
  let orderCount = 0;
  
  for (let i = 1; i < data.length; i++) {
    const orderDate = data[i][0] ? Utilities.formatDate(new Date(data[i][0]), 'Asia/Kolkata', 'yyyy-MM-dd') : '';
    
    if (orderDate === searchDate && data[i][10] === 'Delivered') {
      const charge = parseFloat(data[i][6].toString().replace(/[^0-9.]/g, '')) || 0;
      totalRevenue += charge;
      orderCount++;
    }
  }
  
  console.log(`Revenue for ${searchDate}: ₹${totalRevenue} (${orderCount} orders)`);
  return { date: searchDate, revenue: totalRevenue, orders: orderCount };
}
