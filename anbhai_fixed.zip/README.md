# AN Clinic Website Setup

## Changed files
- `index.html`: gallery now loads from Google Sheets.
- `shopping.html`: shopping page now loads medicines from Google Sheets and uploads images to Cloudinary.
- `shopping.js`: new shopping-page logic.
- `MASTER_GAS.gs`: added Medicines, Gallery, and ShoppingOrders support.

## Replace these values
In both HTML files:
- `YOUR_SCRIPT_ID` with your deployed Google Apps Script Web App URL.

In `shopping.html`:
- `YOUR_CLOUDINARY_CLOUD_NAME`
- `YOUR_UNSIGNED_UPLOAD_PRESET`

## Google Sheets tabs
The Apps Script will create and use:
- `Medicines`
- `Gallery`
- `ShoppingOrders`
- `MedicineOrders`
- `Appointments`
- `Announcements`
- `Feedback`
- `Config`

## What to edit in Sheets
### Medicines
Columns:
`Timestamp | Name | ImageURL | Category | Description | Available | Price`

Put the public medicine image URL in `ImageURL`.

### Gallery
Columns:
`Timestamp | Title | Caption | ImageURL | Active | Order | Icon`

Put the public website/gallery image URL in `ImageURL`.

## Cloudinary
The shopping page uploads prescription and payment screenshots directly to Cloudinary. The returned `secure_url` is saved into Google Sheets.

## Footer
The bottom of the site now says:
`Every website creation credits goes to Naitik Singh.`
